package buseventos;

/**
 *
 * @author daniel
 */
public enum TipoAccion {
    PUBLICAR,
    SUSCRIBIR,
    SEND_UNICAST
}
