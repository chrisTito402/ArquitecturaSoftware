package models.enums;

/**
 *
 * @author daniel
 */
public enum ResultadoConfirmarNaves {
    NAVES_CONFIRMADAS,
    EMPEZAR_PARTIDA,
    NAVES_SIN_COLOCAR,
    JUGADOR_NO_ENCONTRADO;
}
