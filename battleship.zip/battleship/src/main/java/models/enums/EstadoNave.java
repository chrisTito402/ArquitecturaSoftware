package models.enums;

/**
 *
 * @author daniel
 */
public enum EstadoNave {

    AVERIADO,
    HUNDIDO,
    SIN_DAÑOS;
}
