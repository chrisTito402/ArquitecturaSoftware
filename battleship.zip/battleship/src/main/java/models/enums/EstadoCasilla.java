package models.enums;

/**
 *
 * @author daniel
 */
public enum EstadoCasilla {

    NO_DISPARADO,
    AGUA,
    YA_DISPARADO;
}
