package models.enums;

/**
 *
 * @author daniel
 */
public enum ColorJugador {

    ROJO,
    AZUL;
}
