package models.enums;

/**
 *
 * @author daniel
 */
public enum OrientacionNave {

    HORIZONTAL,
    VERTICAL;
}
