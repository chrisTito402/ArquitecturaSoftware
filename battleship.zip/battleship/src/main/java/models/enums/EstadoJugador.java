package models.enums;

/**
 *
 * @author daniel
 */
public enum EstadoJugador {

    JUGANDO,
    DERROTADO,
    ABANDONO,
    EN_LOBBY,
    NAVES_CONFIRMADAS;
}
