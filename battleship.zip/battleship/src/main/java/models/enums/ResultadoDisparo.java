package models.enums;

/**
 *
 * @author daniel
 */
public enum ResultadoDisparo {

    AGUA,
    IMPACTO,
    YA_DISPARADO,
    HUNDIMIENTO,
    DISPARO_FUERA_TIEMPO,
    TURNO_INCORRECTO;
}
