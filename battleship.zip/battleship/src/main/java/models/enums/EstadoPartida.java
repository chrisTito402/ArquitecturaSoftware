package models.enums;

/**
 *
 * @author daniel
 */
public enum EstadoPartida {

    EN_CURSO,
    FINALIZADA,
    POR_EMPEZAR;
}
