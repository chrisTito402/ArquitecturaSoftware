package servidor.controlador;

/**
 *
 * @author daniel
 */
public interface IControladorServidor {

    public void manejarMensaje(String json);
}
