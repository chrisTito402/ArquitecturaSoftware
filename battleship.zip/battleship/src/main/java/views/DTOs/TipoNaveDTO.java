package views.DTOs;

/**
 *
 * @author daniel
 */
public enum TipoNaveDTO {
    BARCO,
    SUBMARINO,
    CRUCERO,
    PORTAAVIONES
}
